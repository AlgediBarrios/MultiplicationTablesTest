﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace MultiplicationTablesTestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string table = "";
            var valid = false;

            while (!valid)
            {
                Console.Write("Multiply table of: ");
                table = (Console.ReadLine());
                valid = !string.IsNullOrWhiteSpace(table) &&
                    table.All(c => c >= '0' && c <= '9');

                if (!valid)
                    Console.WriteLine("Please enter a number");
            }

            int table2 = Convert.ToInt32(table);
            MultiplicationTableTest tableTest = new MultiplicationTableTest(table2);
            tableTest.LoadTable();

        }

       
    }
}
