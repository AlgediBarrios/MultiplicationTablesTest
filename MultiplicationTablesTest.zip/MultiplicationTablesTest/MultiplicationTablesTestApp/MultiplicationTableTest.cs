﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.XPath;

namespace MultiplicationTablesTestApp
{
    class MultiplicationTableTest
    {

        private int pass = 0;
        public int table { get; set; }

        public MultiplicationTableTest(int Table)
        {
            this.table = Table;
        }

        public string Calculate(int table, int number, int total)
        {
            string TextResult = "";
            if (table * number == total)
            {
                TextResult = "Great! That is correct!";
                pass++;
            }
            else
            {
                TextResult = $"The correct answer is {table * number}";
            }
            return TextResult;
        }

        public string ShowSentence(int i)
        {
            string Sentence = "";
            Sentence = $"{this.table} X {i} = ";
            return Sentence;
        }

        public void LoadTable()
        {
            Random rnd = new Random();
            List<int> TableList = new List<int>();
            int TableValue = rnd.Next(1, 10);

            do
            {
                TableValue = rnd.Next(1, 11);
                if (!TableList.Contains(TableValue))
                {
                    TableList.Add(TableValue);
                }
            } while (TableList.Count < 10 );

            Evaluate(TableList);

            Console.Write(FinalResult(pass));
        }

        public void Evaluate(List<int> TableList)
        {
            int Total = 0;
            foreach (int i in TableList)
            {
                Console.Write(ShowSentence(i));

                Total = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine(Calculate(this.table, i, Total));
            }
        }

        public string FinalResult(int pass) {
            string ResultMessage = "";
            ResultMessage = $"You had {pass} right answers! ";
            if (pass == 10) { ResultMessage = ResultMessage + "Congratulations!!!"; }
            return ResultMessage;
        }

    }
}
